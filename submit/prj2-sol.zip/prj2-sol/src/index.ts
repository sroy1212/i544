#!/usr/bin/env node

import main from './lib/main.js';

await main(process.argv.slice(2));
