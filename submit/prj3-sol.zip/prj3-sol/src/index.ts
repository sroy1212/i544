#!/usr/bin/env node

import main from './lib/main.js';

main().catch(err => console.error(err));
